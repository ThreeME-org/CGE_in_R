#' Database for translation with trad function
#'
#' @name trad_language_base
#' @docType data
#' @author ThreeME
#' @source threeme team
#' @format data.frame
#' @keywords language threeme
#'
#' ##Dataexport
"trad_language_base"
