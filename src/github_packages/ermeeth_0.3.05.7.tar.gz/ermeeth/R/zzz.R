.onLoad<-function(libname, pkgname){

  cat("\nHello ! Welcome to ermeeth :) \n")
}
# system.file("dynamo.zip",package = "ermeeth")
