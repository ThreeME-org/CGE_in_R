#' palette_pays
#'
#' Description.
#'
#' @format A data frame with 41 rows and 5 variables:
#' \describe{
#'   \item{ ISO3 }{  character }
#'   \item{ label_fr }{  character }
#'   \item{ label_en }{  character }
#'   \item{ HEX }{  character }
#'   \item{ R-V-B }{  character }
#' }
#' @source Source
"palette_pays"
