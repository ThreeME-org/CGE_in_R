utils::globalVariables(c("label_unit", ".pt", "ofce_logo", "PositionIdentity", "StatIdentity", "ISO" ))
