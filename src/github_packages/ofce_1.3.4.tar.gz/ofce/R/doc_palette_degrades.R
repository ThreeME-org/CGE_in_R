#' palette_degrades
#'
#' Description.
#'
#' @format A data frame with 26 rows and 2 variables:
#' \describe{
#'   \item{ Nom }{  character }
#'   \item{ Code }{  character }
#' }
#' @source Source
"palette_degrades"
