#' palette_principale
#'
#' Description.
#'
#' @format A data frame with 8 rows and 4 variables:
#' \describe{
#'   \item{ Nom }{  numeric }
#'   \item{ Code }{  character }
#'   \item{ R-V-B }{  character }
#'   \item{ Observations }{  character }
#' }
#' @source Source
"palette_principale"
