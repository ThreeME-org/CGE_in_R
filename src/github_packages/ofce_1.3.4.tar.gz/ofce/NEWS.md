## OFCE 1.3.4

* source_data() : correction de plusieurs bugs

## OFCE 1.3.3

* source_data() tracke des fichiers et peut *unfreezer* un qmd

## OFCE 1.3.2

* source_data() utilise un id unique pour chaque utilisateur, pour ne pas déclencher de conflits dans github
* source_data() accepte des arguments passés au source exécuté.

## OFCE 1.3.1

* source_data() utilise maintenant fs pour les fichiers - ce qui doit être plus robuste.

## OFCE 1.3.0

* ajout de source_data(), et de source_data_status()

## OFCE 1.2.1

* corrections de bugs 

## OFCE 1.2.0
  
* ajout de ofce_caption() ; ajout de scale_ofce_date()

* corrections de bugs mineurs

## OFCE 1.1.0

* documentation et vignettes

## OFCE 1.0.0

* première version avec notamment les fonctionspkg

** theme_ofce()
** setup_quarto()
** setup_wp()

